termproject.py may be directly run
termproject-mazeGraphics.py requires numpy and matplotlib, since we aren't building a renderer from scratch